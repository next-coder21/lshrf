import { useState, useEffect, useMemo } from 'react';
import { Shield, Lock, Trash2, Plus, Info, ChevronRight, CheckCircle2, ShieldAlert, Users, Save, X, Activity, Filter } from 'lucide-react';
import toast from 'react-hot-toast';
import { getRoles, getPermissions, createRole, updateRole, deleteRole, Role, Permission } from '../api/roleApi';
import { useSelector } from 'react-redux';
import { RootState } from '../../../store/store';
import { tenantApi } from '../api/tenantApi';

export const RoleListPage = () => {
    // Auth context
    const user = useSelector((state: RootState) => state.auth.user);
    const isSuperAdmin = user?.role === 'SUPER_ADMIN';
    const isClientAdmin = user?.role === 'CLIENT_ADMIN';

    // State
    const [roles, setRoles] = useState<Role[]>([]);
    const [permissions, setPermissions] = useState<Permission[]>([]);
    const [tenants, setTenants] = useState<any[]>([]);
    const [selectedTenantId, setSelectedTenantId] = useState<string>('');
    const [loading, setLoading] = useState(true);
    const [selectedRole, setSelectedRole] = useState<Role | null>(null);
    const [isCreating, setIsCreating] = useState(false);
    const [saving, setSaving] = useState(false);

    // Form state (for creating/editing)
    const [formName, setFormName] = useState('');
    const [formDesc, setFormDesc] = useState('');
    const [selectedPerms, setSelectedPerms] = useState<Set<string>>(new Set());

    useEffect(() => {
        if (isSuperAdmin) {
            loadTenants();
        }
        loadData();
    }, [selectedTenantId]);

    const loadTenants = async () => {
        try {
            const data = await tenantApi.getAll();
            setTenants(data || []);
        } catch (error) {
            console.error('Failed to load tenants', error);
        }
    };

    const loadData = async () => {
        try {
            setLoading(true);
            const [rolesData, permsData] = await Promise.all([
                getRoles(selectedTenantId || undefined), 
                getPermissions()
            ]);
            setRoles(rolesData);
            setPermissions(permsData);
            if (rolesData.length > 0) handleSelectRole(rolesData[0]);
        } catch (error) {
            toast.error('Failed to initialize authorization protocols');
        } finally {
            setLoading(false);
        }
    };

    const handleSelectRole = (role: Role) => {
        setIsCreating(false);
        setSelectedRole(role);
        setFormName(role.name);
        setFormDesc(role.description || '');
        setSelectedPerms(new Set(role.permissions));
    };

    const handleStartCreate = () => {
        setIsCreating(true);
        setSelectedRole(null);
        setFormName('');
        setFormDesc('');
        setSelectedPerms(new Set());
    };

    const togglePerm = (permName: string) => {
        if (selectedRole?.isSystem) return;
        const newPerms = new Set(selectedPerms);
        if (newPerms.has(permName)) newPerms.delete(permName);
        else newPerms.add(permName);
        setSelectedPerms(newPerms);
    };

    const handleSave = async () => {
        if (!formName.trim()) {
            toast.error('Identity signature required');
            return;
        }

        setSaving(true);
        try {
            const payload = {
                name: formName.trim(),
                description: formDesc.trim(),
                permissions: Array.from(selectedPerms) as string[]
            };

            if (isCreating) {
                await createRole(payload);
                toast.success('Custom protocol deployed');
            } else if (selectedRole?.id) {
                await updateRole(selectedRole.id, payload);
                toast.success('Access matrix updated');
            }
            loadData();
        } catch (err: any) {
            toast.error(err.response?.data?.message || 'Protocol update failed');
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async () => {
        if (!selectedRole?.id || selectedRole.isSystem) return;
        
        if (selectedRole.userCount > 0) {
            toast.error(`Access locked: ${selectedRole.userCount} users currently using this role`);
            return;
        }

        if (!confirm(`Permanently de-authorize role "${selectedRole.displayName}"?`)) return;

        try {
            setSaving(true);
            await deleteRole(selectedRole.id);
            toast.success('Role purged from system');
            loadData();
        } catch (err: any) {
            toast.error(err.response?.data?.message || 'Purge protocol failed');
        } finally {
            setSaving(false);
        }
    };

    // Grouping
    const groupedPermissions = useMemo(() => {
        const groups: Record<string, Permission[]> = {};
        permissions.forEach((p: Permission) => {
            if (!groups[p.category]) groups[p.category] = [];
            groups[p.category].push(p);
        });
        return groups;
    }, [permissions]);

    const systemRoles = roles.filter((r: Role) => r.isSystem);
    const customRoles = roles.filter((r: Role) => !r.isSystem);

    return (
        <div className="p-8 space-y-6 animate-in fade-in duration-500 max-w-[1600px] mx-auto">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-black text-gray-900 tracking-tight uppercase">
                        Role <span className="text-red-600">Operations</span>
                    </h1>
                    <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">
                        Deployment Infrastructure • Cross-Tenant Security
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* LEFT PANEL: Roles List */}
                <div className="lg:col-span-4 space-y-8">
                    
                    {/* Tenant Selector for Super Admin */}
                    {isSuperAdmin && (
                        <div className="space-y-4">
                            <div className="flex items-center gap-2 px-2">
                                <Filter className="w-3.5 h-3.5 text-red-600" />
                                <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Cross-Organization Scope</h3>
                            </div>
                            <select
                                value={selectedTenantId}
                                onChange={(e) => setSelectedTenantId(e.target.value)}
                                className="w-full px-5 py-3 rounded-2xl bg-white border border-gray-100 text-[10px] font-black uppercase tracking-widest outline-none shadow-sm focus:border-red-500 transition-all"
                            >
                                <option value="">Global System (Self)</option>
                                {tenants.map((t: any) => (
                                    <option key={t.id} value={t.id}>{t.name}</option>
                                ))}
                            </select>
                        </div>
                    )}
                    
                    {/* System Hierarchy */}
                    <div className="space-y-4">
                        <div className="flex items-center justify-between px-2">
                            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">System Prototypes</h3>
                            <Lock className="w-3 h-3 text-gray-300" />
                        </div>
                        <div className="space-y-2">
                            {loading ? [1, 2, 3].map(i => <div key={i} className="h-16 bg-gray-50 rounded-2xl animate-pulse" />) :
                            systemRoles.map((role: Role) => (
                                <button
                                    key={role.name}
                                    onClick={() => handleSelectRole(role)}
                                    className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between group ${
                                        selectedRole?.name === role.name 
                                        ? 'bg-gray-900 border-gray-900 shadow-xl' 
                                        : 'bg-white border-gray-100 hover:border-red-100'
                                    }`}
                                >
                                    <div className="flex items-center gap-3">
                                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                                            selectedRole?.name === role.name ? 'bg-red-600 text-white' : 'bg-gray-50 text-gray-400 group-hover:bg-red-50'
                                        }`}>
                                            <Shield className="w-4 h-4" />
                                        </div>
                                        <div>
                                            <p className={`text-[10px] font-black uppercase tracking-widest ${selectedRole?.name === role.name ? 'text-white' : 'text-gray-900'}`}>
                                                {role.displayName}
                                            </p>
                                            <span className="text-[8px] font-bold text-gray-400 uppercase">{role.userCount} Members</span>
                                        </div>
                                    </div>
                                    <ChevronRight className={`w-3.5 h-3.5 ${selectedRole?.name === role.name ? 'text-red-500' : 'text-gray-200 opacity-0 group-hover:opacity-100'}`} />
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Custom Definitions */}
                    <div className="space-y-4">
                        <div className="flex items-center justify-between px-2">
                            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Custom Instances</h3>
                            {(isSuperAdmin || isClientAdmin) && (
                                <button 
                                    onClick={handleStartCreate}
                                    className="p-1.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors shadow-lg active:scale-95"
                                >
                                    <Plus className="w-3.5 h-3.5" />
                                </button>
                            )}
                        </div>
                        <div className="space-y-2">
                            {!loading && customRoles.length === 0 && !isCreating && (
                                <div className="p-8 border-2 border-dashed border-gray-100 rounded-3xl text-center">
                                    <p className="text-[9px] font-black text-gray-300 uppercase tracking-widest">No custom roles deployed</p>
                                </div>
                            )}
                            {customRoles.map((role: Role) => (
                                <button
                                    key={role.id}
                                    onClick={() => handleSelectRole(role)}
                                    className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between group ${
                                        selectedRole?.id === role.id 
                                        ? 'bg-gray-900 border-gray-900 shadow-xl' 
                                        : 'bg-white border-gray-100 hover:border-red-100 shadow-sm'
                                    }`}
                                >
                                    <div className="flex items-center gap-3">
                                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
                                            selectedRole?.id === role.id ? 'bg-red-600 text-white' : 'bg-gray-50 text-gray-400 group-hover:bg-red-50'
                                        }`}>
                                            <Activity className="w-4 h-4" />
                                        </div>
                                        <div>
                                            <p className={`text-[10px] font-black uppercase tracking-widest ${selectedRole?.id === role.id ? 'text-white' : 'text-gray-900'}`}>
                                                {role.displayName}
                                            </p>
                                            <span className="text-[8px] font-bold text-gray-400 uppercase">{role.userCount} Members</span>
                                        </div>
                                    </div>
                                    <ChevronRight className={`w-3.5 h-3.5 ${selectedRole?.id === role.id ? 'text-red-500' : 'text-gray-200 opacity-0 group-hover:opacity-100'}`} />
                                </button>
                            ))}
                            {isCreating && (
                                <div className="p-4 rounded-2xl border-2 border-red-200 bg-red-50/20 ring-4 ring-red-500/5 flex items-center gap-3">
                                    <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center">
                                        <Plus className="w-4 h-4" />
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-black uppercase text-red-600 tracking-widest">New Deployment</p>
                                        <span className="text-[8px] font-bold text-gray-400 uppercase italic whitespace-nowrap">Awaiting Configuration</span>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* RIGHT PANEL: Editor */}
                <div className="lg:col-span-8">
                    {(selectedRole || isCreating) ? (
                        <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-2xl relative overflow-hidden transition-all duration-500 animate-in slide-in-from-right-8">
                            
                            {/* Editor Header */}
                            <div className="p-8 border-b border-gray-100 flex items-start justify-between bg-gradient-to-br from-white to-gray-50/50">
                                <div className="space-y-4 flex-1 pr-12">
                                    <div className="flex items-center gap-2">
                                        <div className="p-2 bg-red-50 text-red-600 rounded-xl">
                                            <ShieldAlert className="w-5 h-5" />
                                        </div>
                                        <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight">
                                            {isCreating ? 'Deploy New' : 'Refine'} <span className="text-red-600">Access Layer</span>
                                        </h2>
                                    </div>
                                    
                                    <div className="grid grid-cols-1 gap-4">
                                        <div className="space-y-1">
                                            <label className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] ml-1">Identity Signature</label>
                                            <input
                                                type="text"
                                                value={formName}
                                                onChange={(e) => setFormName(e.target.value)}
                                                readOnly={selectedRole?.isSystem}
                                                placeholder="e.g. Finance Controller"
                                                className={`w-full px-5 py-3 rounded-2xl text-xs font-bold transition-all outline-none ${
                                                    selectedRole?.isSystem 
                                                    ? 'bg-gray-50 text-gray-500 border-transparent cursor-not-allowed' 
                                                    : 'bg-white border border-gray-100 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 shadow-sm'
                                                }`}
                                            />
                                        </div>
                                        <div className="space-y-1">
                                            <label className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] ml-1">Operational Directive</label>
                                            <input
                                                type="text"
                                                value={formDesc}
                                                onChange={(e) => setFormDesc(e.target.value)}
                                                readOnly={selectedRole?.isSystem}
                                                placeholder="Briefly describe the responsibilities of this role..."
                                                className={`w-full px-5 py-3 rounded-2xl text-xs font-bold transition-all outline-none ${
                                                    selectedRole?.isSystem 
                                                    ? 'bg-gray-50 text-gray-400 border-transparent cursor-not-allowed italic font-medium' 
                                                    : 'bg-white border border-gray-100 focus:border-red-500 focus:ring-4 focus:ring-red-500/5 shadow-sm'
                                                }`}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="flex flex-col items-end gap-3">
                                    {selectedRole?.isSystem ? (
                                        <div className="flex items-center gap-1.5 px-4 py-2 bg-gray-900 text-white rounded-xl shadow-lg">
                                            <Lock className="w-3.5 h-3.5 text-red-500" />
                                            <span className="text-[10px] font-black uppercase tracking-widest whitespace-nowrap">Core Immutable Layer</span>
                                        </div>
                                    ) : (
                                        <div className="flex items-center gap-2">
                                            {selectedRole && (
                                                <button 
                                                    onClick={handleDelete}
                                                    className="w-10 h-10 flex items-center justify-center bg-gray-50 text-gray-400 hover:bg-red-50 hover:text-red-600 rounded-xl border border-gray-100 transition-all"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </button>
                                            )}
                                            <button 
                                                onClick={handleSave}
                                                disabled={saving}
                                                className="px-6 py-2.5 bg-red-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-red-500/20 hover:bg-red-700 transition-all active:scale-95 disabled:opacity-50"
                                            >
                                                <Save className="w-3.5 h-3.5" />
                                                {saving ? 'Processing...' : (isCreating ? 'Deploy Protocol' : 'Sync Changes')}
                                            </button>
                                        </div>
                                    )}
                                </div>
                            </div>

                            {/* Permissions Grid */}
                            <div className="p-8 max-h-[600px] overflow-y-auto scrollbar-hide">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10">
                                    {Object.entries(groupedPermissions).map(([category, perms]) => (
                                        <div key={category} className="space-y-4">
                                            <div className="flex items-center justify-between pb-2 border-b border-gray-100">
                                                <h5 className="text-[10px] font-black text-gray-900 uppercase tracking-[0.2em]">{category}</h5>
                                                {!(selectedRole?.isSystem) && (
                                                    <button 
                                                        onClick={() => {
                                                            const allCat = (perms as Permission[]).map((p: Permission) => p.name);
                                                            const currentSet = new Set(selectedPerms);
                                                            const hasAll = allCat.every((p: string) => currentSet.has(p));
                                                            if (hasAll) allCat.forEach((p: string) => currentSet.delete(p));
                                                            else allCat.forEach((p: string) => currentSet.add(p));
                                                            setSelectedPerms(currentSet);
                                                        }}
                                                        className="text-[9px] font-black text-red-600 hover:underline uppercase"
                                                    >
                                                        Toggle Section
                                                    </button>
                                                )}
                                            </div>
                                            <div className="grid grid-cols-1 gap-2">
                                                {(perms as Permission[]).map((p: Permission) => {
                                                    const active = selectedPerms.has(p.name);
                                                    return (
                                                        <label 
                                                            key={p.name} 
                                                            className={`flex items-center gap-3 p-3 rounded-xl transition-all border ${
                                                                active 
                                                                ? 'bg-red-50/30 border-red-100' 
                                                                : 'bg-white border-transparent'
                                                            } ${selectedRole?.isSystem ? 'cursor-default' : 'cursor-pointer hover:bg-gray-50'}`}
                                                        >
                                                            <div className="relative flex items-center">
                                                                <input
                                                                    type="checkbox"
                                                                    checked={active}
                                                                    onChange={() => togglePerm(p.name)}
                                                                    disabled={selectedRole?.isSystem}
                                                                    className="w-4 h-4 rounded-md accent-red-600 cursor-pointer disabled:opacity-30"
                                                                />
                                                                {active && <CheckCircle2 className="w-2.5 h-2.5 absolute left-[3px] top-[3px] text-white pointer-events-none" />}
                                                            </div>
                                                            <span className={`text-[11px] font-bold uppercase transition-colors ${
                                                                active ? 'text-gray-900' : 'text-gray-400'
                                                            }`}>
                                                                {p.displayName}
                                                            </span>
                                                        </label>
                                                    );
                                                })}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Editor Footer */}
                            <div className="p-6 bg-gray-50 border-t border-gray-100 flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <div className="flex items-center gap-1.5 text-gray-500 text-[10px] font-bold uppercase tracking-widest pl-2">
                                        <Lock className={`w-3 h-3 ${selectedRole?.isSystem ? 'text-red-500' : 'text-emerald-500'}`} />
                                        Encryption: RSA-4096 Enabled
                                    </div>
                                </div>
                                {isCreating && (
                                    <button 
                                        onClick={() => { setIsCreating(false); if (roles.length > 0) handleSelectRole(roles[0]); }}
                                        className="text-[10px] font-black text-gray-400 hover:text-gray-900 uppercase tracking-widest flex items-center gap-2"
                                    >
                                        <X className="w-3.5 h-3.5" />
                                        Abort Operation
                                    </button>
                                )}
                            </div>
                        </div>
                    ) : (
                        <div className="h-[700px] border-2 border-dashed border-gray-100 rounded-[3rem] flex flex-col items-center justify-center text-gray-400 gap-6 group hover:border-red-100 transition-all">
                            <div className="w-24 h-24 rounded-[2rem] bg-gray-50 flex items-center justify-center group-hover:bg-red-50 transition-colors">
                                <Shield className="w-10 h-10 opacity-10 group-hover:scale-110 transition-transform" />
                            </div>
                            <div className="text-center space-y-2">
                                <p className="text-[10px] font-black uppercase tracking-[0.3em]">Protocol Matrix Inactive</p>
                                <p className="text-[9px] font-bold text-gray-300 uppercase italic">Select or deploy a new access layer to begin configuration</p>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};
