import { useState, useEffect } from 'react';
import { X, User, Mail, Phone, Building2, Briefcase, Calendar, DollarSign, CheckCircle } from 'lucide-react';
import { Employee, EmployeeRequest, EmploymentStatus } from '../types/employee.types';
import clsx from 'clsx';

interface EmployeeFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (data: EmployeeRequest) => Promise<void>;
    initialData?: Employee | null;
}

export const EmployeeFormModal = ({ isOpen, onClose, onSubmit, initialData }: EmployeeFormModalProps) => {
    const [formData, setFormData] = useState<EmployeeRequest>({
        employeeId: '',
        firstName: '',
        lastName: '',
        email: '',
        phoneNumber: '',
        department: '',
        designation: '',
        salary: 0,
        status: 'ACTIVE',
    });
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (initialData) {
            setFormData({
                employeeId: initialData.employeeId,
                firstName: initialData.firstName,
                lastName: initialData.lastName,
                email: initialData.email,
                phoneNumber: initialData.phoneNumber,
                department: initialData.department,
                designation: initialData.designation,
                salary: initialData.salary,
                status: initialData.status,
            });
        } else {
            setFormData({
                employeeId: '',
                firstName: '',
                lastName: '',
                email: '',
                phoneNumber: '',
                department: '',
                designation: '',
                salary: 0,
                status: 'ACTIVE',
            });
        }
    }, [initialData]);

    if (!isOpen) return null;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            await onSubmit(formData);
            onClose();
        } catch (error) {
            console.error('Failed to submit:', error);
        } finally {
            setIsSubmitting(false);
        }
    };

    const inputClasses = "w-full bg-gray-50 border border-gray-100 rounded-xl py-2.5 px-4 text-sm focus:ring-2 focus:ring-red-500/20 focus:bg-white focus:border-red-500/50 transition-all font-medium outline-none";
    const labelClasses = "text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block";

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
            <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose} />

            <div className="relative bg-white w-full max-w-2xl rounded-[2rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
                {/* Header */}
                <div className="p-6 md:p-8 border-b border-gray-50 flex items-center justify-between bg-gradient-to-r from-gray-50 to-white">
                    <div>
                        <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight">
                            {initialData ? 'Update' : 'Register'} <span className="text-red-600">Personnel</span>
                        </h2>
                        <p className="text-xs text-gray-500 font-medium">Enter detailed workforce information below.</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all text-gray-400 hover:text-gray-900">
                        <X className="w-6 h-6" />
                    </button>
                </div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Basic Info */}
                        <div className="space-y-4">
                            <div>
                                <label className={labelClasses}>Employee ID</label>
                                <div className="relative">
                                    <input
                                        type="text"
                                        required
                                        disabled={!!initialData}
                                        value={formData.employeeId}
                                        onChange={e => setFormData({ ...formData, employeeId: e.target.value })}
                                        className={clsx(inputClasses, !!initialData && "opacity-50 cursor-not-allowed")}
                                        placeholder="EMP001"
                                    />
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className={labelClasses}>First Name</label>
                                    <input
                                        type="text"
                                        required
                                        value={formData.firstName}
                                        onChange={e => setFormData({ ...formData, firstName: e.target.value })}
                                        className={inputClasses}
                                        placeholder="John"
                                    />
                                </div>
                                <div>
                                    <label className={labelClasses}>Last Name</label>
                                    <input
                                        type="text"
                                        required
                                        value={formData.lastName}
                                        onChange={e => setFormData({ ...formData, lastName: e.target.value })}
                                        className={inputClasses}
                                        placeholder="Doe"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className={labelClasses}>Email Address</label>
                                <input
                                    type="email"
                                    required
                                    value={formData.email}
                                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                                    className={inputClasses}
                                    placeholder="john.doe@lishr.com"
                                />
                            </div>
                            <div>
                                <label className={labelClasses}>Phone Number</label>
                                <input
                                    type="tel"
                                    value={formData.phoneNumber}
                                    onChange={e => setFormData({ ...formData, phoneNumber: e.target.value })}
                                    className={inputClasses}
                                    placeholder="+1 (555) 000-0000"
                                />
                            </div>
                        </div>

                        {/* Professional Info */}
                        <div className="space-y-4">
                            <div>
                                <label className={labelClasses}>Department</label>
                                <select
                                    required
                                    value={formData.department}
                                    onChange={e => setFormData({ ...formData, department: e.target.value })}
                                    className={inputClasses}
                                >
                                    <option value="">Select Department</option>
                                    <option value="Engineering">Engineering</option>
                                    <option value="Product">Product</option>
                                    <option value="Design">Design</option>
                                    <option value="Marketing">Marketing</option>
                                    <option value="Operations">Operations</option>
                                    <option value="HR">HR</option>
                                </select>
                            </div>
                            <div>
                                <label className={labelClasses}>Designation</label>
                                <input
                                    type="text"
                                    required
                                    value={formData.designation}
                                    onChange={e => setFormData({ ...formData, designation: e.target.value })}
                                    className={inputClasses}
                                    placeholder="Software Engineer"
                                />
                            </div>
                            <div>
                                <label className={labelClasses}>Monthly Salary ($)</label>
                                <input
                                    type="number"
                                    required
                                    value={formData.salary}
                                    onChange={e => setFormData({ ...formData, salary: Number(e.target.value) })}
                                    className={inputClasses}
                                    placeholder="5000"
                                />
                            </div>
                            <div>
                                <label className={labelClasses}>Employment Status</label>
                                <select
                                    required
                                    value={formData.status}
                                    onChange={e => setFormData({ ...formData, status: e.target.value as EmploymentStatus })}
                                    className={inputClasses}
                                >
                                    <option value="ACTIVE">Active</option>
                                    <option value="INACTIVE">Inactive</option>
                                    <option value="ON_LEAVE">On Leave</option>
                                    <option value="TERMINATED">Terminated</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    {/* Footer Actions */}
                    <div className="pt-6 flex items-center justify-end gap-3 border-t border-gray-50">
                        <button
                            type="button"
                            onClick={onClose}
                            className="px-6 py-2.5 text-xs font-bold text-gray-500 uppercase tracking-widest hover:text-gray-900 transition-all"
                        >
                            Cancel
                        </button>
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="flex items-center gap-2 px-8 py-2.5 bg-gray-900 text-white rounded-xl font-bold hover:bg-gray-800 transition-all shadow-lg hover:shadow-gray-400/30 text-xs uppercase tracking-widest active:scale-95 disabled:opacity-50"
                        >
                            {isSubmitting ? (
                                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            ) : (
                                <CheckCircle className="w-4 h-4" />
                            )}
                            {initialData ? 'Save Changes' : 'Confirm Registration'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
